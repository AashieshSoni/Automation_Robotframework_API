import random
#import itertools # Needed for one of the 'without replacement' methods

def select_single_weighted(items, weights):
    """
    Selects a single item from a list based on corresponding weights.

    Args:
        items (list): The list of items to choose from.
        weights (list): A list of weights corresponding to the items.
                        Must be the same length as items. Weights can be
                        any non-negative numbers (ints or floats).
                        Higher weights increase the chance of selection.

    Returns:
        The selected item.

    Raises:
        ValueError: If items and weights have different lengths,
                    if lists are empty, or if all weights are zero or negative.
    """
    if len(items) != len(weights):
        raise ValueError("Items and weights must have the same length.")
    if not items:
        raise ValueError("Input lists cannot be empty.")
    if all(w <= 0 for w in weights):
         raise ValueError("At least one weight must be positive.")

    # random.choices returns a list (even for k=1), so get the first element
    selected_list = random.choices(items, weights=weights, k=1)
    return selected_list[0]

def select_multi_weighted_with_replacement(items, weights, mcount):
    """
    Selects multiple items from a list based on weights, WITH replacement.
    This means the same item can be selected multiple times.

    Args:
        items (list): The list of items to choose from.
        weights (list): A list of weights corresponding to the items.
                        Must be the same length as items.
        mcount (int): The number of items to select.

    Returns:
        list: A list containing the selected items (length will be mcount).

    Raises:
        ValueError: If items and weights have different lengths,
                    if lists are empty, if mcount is not positive,
                    or if all weights are zero or negative.
    """
    if len(items) != len(weights):
        raise ValueError("Items and weights must have the same length.")
    if not items:
        raise ValueError("Input lists cannot be empty.")
    if mcount <= 0:
        raise ValueError("mcount (number of items to select) must be positive.")
    if all(w <= 0 for w in weights):
         raise ValueError("At least one weight must be positive.")

    selected = random.choices(items, weights=weights, k=mcount)
    return selected # Returns a list

def select_multi_weighted_without_replacement(items, weights, mcount):
    """
    Selects multiple UNIQUE items from a list based on weights, WITHOUT replacement.
    This behaves more like random.sample but respects weights.

    Args:
        items (list): The list of items to choose from.
        weights (list): A list of weights corresponding to the items.
                        Must be the same length as items.
        mcount (int): The number of unique items to select.

    Returns:
        list: A list containing the selected unique items (length will be mcount).

    Raises:
        ValueError: If items and weights have different lengths,
                    if lists are empty, if mcount is not positive,
                    if mcount is greater than the number of items available,
                    or if all weights are zero or negative.
    """
    if len(items) != len(weights):
        raise ValueError("Items and weights must have the same length.")
    if not items:
        raise ValueError("Input lists cannot be empty.")
    if mcount <= 0:
        raise ValueError("mcount (number of items to select) must be positive.")
    if mcount > len(items):
        raise ValueError(f"Cannot select {mcount} unique items from a list of {len(items)}.")
    if all(w <= 0 for w in weights):
         raise ValueError("At least one weight must be positive.")


    selected_items = []
    # Keep track of remaining items and their weights
    population = list(items)
    pop_weights = list(weights)

    for _ in range(mcount):
        # Check if population or weights became unexpectedly empty
        if not population:
             raise RuntimeError("Population became empty unexpectedly.") # Should be caught by initial mcount check

        # Recalculate total weight in case items were removed
        total_weight = sum(pop_weights)
        if total_weight <= 0:
            # If remaining weights are all zero, sample uniformly from remaining items
            if all(w == 0 for w in pop_weights):
                chosen_item = random.choice(population)
            else:
                # This case (total_weight <= 0 but not all weights are 0)
                # implies negative weights existed, which isn't typical for random.choices
                # or an issue occurred. Raise error for clarity.
                raise ValueError("Cannot perform weighted selection with non-positive total weight unless all weights are zero.")
        else:
            # Select one item based on current weights
            chosen_list = random.choices(population, weights=pop_weights, k=1)
            chosen_item = chosen_list[0]

        selected_items.append(chosen_item)

        # Find the index of the chosen item to remove it and its weight
        # Handle potential duplicates in the original list if necessary,
        # but here we remove the *first* occurrence found.
        try:
            idx_to_remove = population.index(chosen_item)
            del population[idx_to_remove]
            del pop_weights[idx_to_remove]
        except ValueError:
             # Should not happen since the item was chosen from the population
             raise RuntimeError(f"Chosen item '{chosen_item}' not found in population for removal.")


    return selected_items # Returns a list of unique items


# --- Example Usage ---

my_list = ['apple', 'banana', 'cherry', 'date', 'elderberry']
my_weights = [10, 1, 30, 5, 2] # cherry most likely, banana least likely

print("--- Single Selection ---")
for _ in range(5): # Select 5 times to see variation
    single_selected = select_single_weighted(my_list, my_weights)
    print(f"Selected: {single_selected}")

print("\n--- Multi Selection (With Replacement) ---")
multi_selected_with = select_multi_weighted_with_replacement(my_list, my_weights, 3)
print(f"Selected (k=3, with replacement): {multi_selected_with}")
# Example joining like original function: print(';'.join(multi_selected_with))


print("\n--- Multi Selection (Without Replacement) ---")
multi_selected_without = select_multi_weighted_without_replacement(my_list, my_weights, 3)
print(f"Selected (k=3, without replacement): {multi_selected_without}")
# Example joining like original function: print(';'.join(multi_selected_without))

# Example trying to select more unique items than available
try:
    select_multi_weighted_without_replacement(my_list, my_weights, 6)
except ValueError as e:
    print(f"\nError as expected: {e}")