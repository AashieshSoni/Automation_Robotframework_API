import csv
import datetime
from faker import Faker
import random
import pandas as pd
import numpy as np

Faker.seed(0)
random.seed(0)
fake = Faker("en_CA") 
fixed_digits = 6
concatid = 'ID'
df=pd.read_csv("ACCOUNTRELATIONSHIP_.csv")

def ownerType():
    ownertype = random.choices(['INDIVIDUAL', 'BUSINESS'], weights=[0.5, 0.5])  
    return ownertype

def ownerId(type_owner):
    #lst_owner_id = df[df['CUSTOMER_TYPE'] == s].index.to_numpy()
    dfB = df[df['CUSTOMER_TYPE'] == type_owner]
    return dfB['CUSTOMER_ID'].values.tolist()

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1


def datagenerate(records, headers):
    fake = Faker()
    with open('PHONE_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        owner_id_ind = ownerId('INDIVIDUAL')
        owner_id_bus = ownerId('BUSINESS')
        business_count = len(owner_id_bus)
        individual_count  = len(owner_id_ind)
        j=0
        k=0
        for i in range(records):
            owner_type = ownerType()
            if((listToString(owner_type)=='INDIVIDUAL') and (j<individual_count)):
                OWNER_ID_var = owner_id_ind[j]
                writer.writerow({
                    'OWNER_TYPE': listToString(owner_type),
                    'OWNER_ID': OWNER_ID_var,
                    'TYPE': listToString(random.choices(['WORK', 'HOME','OTHER'], weights=[1, 1,.25])),
                    #Logic for IS_PRIMARY_FOR_TYPE need to correct based on ACCOUNTRELATIONSHIP_-> IS_PRIMARY_FOR_TYPE = true.#
                    'IS_PRIMARY_FOR_TYPE': listToString(random.choices([True, False], weights=[5, 5])),   
                    'NUMBER': fake.random_number(digits=10),
                    'PHONE_ID': fake.random_number(digits=3),
                    'EXTENSION': fake.random_number(digits=2),
                    'COMMENTS': str('valid number'),
                })
                j = j + 1
                
            elif((listToString(owner_type)=='BUSINESS') and (k<individual_count)):
                OWNER_ID_var = owner_id_bus[k]
                writer.writerow({
                    'OWNER_TYPE': listToString(owner_type),
                    'OWNER_ID': OWNER_ID_var,
                    'TYPE': listToString(random.choices(['WORK', 'HOME'], weights=[5, 5])),
                    #Logic for IS_PRIMARY_FOR_TYPE need to correct based on ACCOUNTRELATIONSHIP_-> IS_PRIMARY_FOR_TYPE = true.#                    
                    'IS_PRIMARY_FOR_TYPE': listToString(random.choices([True, False], weights=[5, 5])),
                    'NUMBER': fake.random_number(digits=10),
                    'PHONE_ID': fake.random_number(digits=3),
                    'EXTENSION': fake.random_number(digits=2),
                    'COMMENTS': str('valid number'),
                })
                k = k + 1    

if __name__ == '__main__':
    records =200
    headers = ['OWNER_TYPE', 'OWNER_ID', 'TYPE', 'IS_PRIMARY_FOR_TYPE', 'NUMBER', 'PHONE_ID', 'EXTENSION', 'COMMENTS']
    datagenerate(records, headers)
    print('CSV generation complete!')
