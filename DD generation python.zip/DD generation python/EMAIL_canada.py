import pandas as pd
import csv
import random
from faker import Faker


Faker.seed(0)
random.seed(0)
fake = Faker("en_CA") 

# Load data from ACCOUNTRELATIONSHIP_.csv
df = pd.read_csv('ACCOUNTRELATIONSHIP_.csv')
df.columns = df.columns.str.strip()

# Get unique (CUSTOMER_ID, CUSTOMER_TYPE) pairs
unique_owners = df[['CUSTOMER_ID', 'CUSTOMER_TYPE']].dropna().drop_duplicates().values.tolist()

# Define headers for the new CSV
headers = ['EMAIL_ID', 'OWNER_TYPE', 'OWNER_ID', 'EMAIL', 'IS_PRIMARY','COMMENTS']

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1

def emaildomain():
    emaildomains = ['gmail','hotmail','live','verizon','yahoo','hotmail','comcast']
    emails = listToString(random.choices(emaildomains, weights=[2,2,1,1,2,2,1]))
    return emails
    
def emailextension():
    ext = ['.com','.net','.co.uk']
    emailextension = listToString(random.choices(ext, weights=[4,4,3]))
    return emailextension
	
# Generate email records
email_records = []
for i, (owner_id, owner_type) in enumerate(unique_owners, start=1):
    email_id = f'EM{i:03}'  # EM101, EM102, ...
    email = fake.name().replace(".","").strip().replace(" ","").lower() + '@' + emaildomain() + emailextension()
    
    is_primary = random.choice(['TRUE', 'FALSE'])
    comment = f'{email_id} - {owner_id}'

    row = [email_id, owner_type, owner_id, email, is_primary,comment]
    email_records.append(row)

# Write to new CSV
output_file = 'EMAIL_.csv'
with open(output_file, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(headers)
    writer.writerows(email_records)

print(f"{output_file} created with {len(email_records)} records.")
