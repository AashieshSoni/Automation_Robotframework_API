import csv
from faker import Faker
import random
import pandas as pd

# Initialize Faker
Faker.seed(0)
random.seed(0)
fake = Faker("en_CA") 

# Load the input files
individual_df = pd.read_csv('INDIVIDUAL_.csv')
business_df = pd.read_csv('BUSINESS_.csv')

# Extract unique IDs
individual_ids = individual_df['INDIVIDUAL_ID'].dropna().unique()
business_ids = business_df['BUSINESS_ID'].dropna().unique()

relationshiptype=['BENEFICIAL_OWNER','CONTROLLING_PARTY']

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1
    
# Function to generate data and write to CSV
def datagenerate(records, headers):
    with open('INDIVIDUALBUSINESSRELATIONSHIP_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            writer.writerow({
                'INDIVIDUAL_ID': individual_ids[i % len(individual_ids)],  # Ensure it wraps if more records than IDs
                'BUSINESS_ID': business_ids[i % len(business_ids)],  # Ensure it wraps if more records than IDs
                'RELATIONSHIP_TYPE': random.choice(relationshiptype),  # Use choice instead of choices
                'OWNERSHIP_PERCENTAGE': random.randint(20, 90),
                'OWNERSHIP_STATUS': random.choices(['ACTIVE', 'INACTIVE'], weights=[1.9, 0.1])[0],  # Get the first element
                'COMMENTS': f'Relationship {individual_ids[i % len(individual_ids)]} & business_id-{business_ids[i % len(business_ids)]}',  # Fix concatenation
            })

if __name__ == '__main__':
    records = 200
    headers = ['INDIVIDUAL_ID', 'BUSINESS_ID', 'RELATIONSHIP_TYPE', 'OWNERSHIP_PERCENTAGE', 'OWNERSHIP_STATUS', 'COMMENTS']
    datagenerate(records, headers)
    print('CSV generation complete!')