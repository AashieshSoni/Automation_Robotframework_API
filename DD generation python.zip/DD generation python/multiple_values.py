import sys
import random
# Installing libraries
# !{sys.executable} -m pip install pandas --quiet
import pandas as pd

  
def pick_two_countries(country_list, multiple_count):
    if len(country_list) < multiple_count:
        raise ValueError("Need at least two countries to pick from.")
    selected = random.sample(country_list, multiple_count)
    return ';'.join(selected)


def filter_countries(country_list):
    filtered = [country for country in countries if country not in ['United States', 'American Samoa']]
    return ';'.join(filtered)

# Example usage
country_list = ['American Samoa', 'Canada', 'France', 'United States', 'India']
multiple_cnt = 3
result = pick_two_countries(country_list,multiple_cnt)
print(result)  # e.g., "France;India"
