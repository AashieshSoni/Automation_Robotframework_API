import csv
import datetime
from faker import Faker
import random
import pandas as pd
from mimesis import Datetime

Faker.seed(0)
random.seed(0)
fake = Faker("en_US") 
datetime = Datetime()

# Load the input files
accountrelationship_df = pd.read_csv('ACCOUNTnum_.csv')

# Extract unique IDs
ACCOUNTnums = accountrelationship_df['ACCOUNT'].dropna().unique()
print(ACCOUNTnums.head())

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1   

def datagenerate(records, headers):
    fake = Faker()
    with open('ACCOUNT_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            writer.writerow({
                    'NUMBER': fake.random_number(digits=6),
                    'TYPE': listToString(random.choices(['LOAN','BOND','CERTIFICATE_DEPOSIT','CHECKING','CREDIT_CARD','EDUCATION_SAVINGS','IRA','OTHER','ROTH_IRA','SAVINGS','LINE_OF_CREDIT','TRUST','FOREIGN_CURRENCY','MONEY_MARKET','BROKERAGE'], weights=[5,1,1,1,1,1,1,1,1,1,1,1,1,1,1])),
                    'PRODUCT_NAME'  : listToString(random.choices(['LOAN','EDUCATION','OTHER'], weights=[5,5,5])),
                    'STATUS'  : listToString(random.choices(['ACTIVE','CLOSED','FROZEN','INACTIVE','DORMANT'], weights=[6,1,1,1,1])),
                    'OPEN_DATE': fake.date_time_between(start_date='-15y', end_date='now'),
                    'CLOSE_DATE': str(""),
                    'REOPEN_DATE': str(""),
                    'INITIAL_BALANCE' : fake.random_int(100, 30000),
                    'CURRENT_BALANCE' : fake.random_int(10000, 50000),
                    'BRANCH_ID': fake.random_number(digits=4),
                    'LOAN_RELEASE_DATE' : fake.date_time_between(start_date='-5y', end_date='now'),
                    'LOAN_AMOUNT'   :fake.random_int(0, 1000000),
                    'LOAN_INSTALLMENT_AMOUNT'   :fake.random_int(0, 1000000),
                    'LOAN_MATURITY_DATE' : fake.date_time_between(start_date='-5y', end_date='now'),
                    'COMMENTS': listToString(random.choices(['VALID','INVALID','OTHER'], weights=[4,3,3])),
                })


if __name__ == '__main__':
    records = 10
    headers = ['NUMBER','TYPE','PRODUCT_NAME','STATUS','OPEN_DATE','CLOSE_DATE','REOPEN_DATE','INITIAL_BALANCE','CURRENT_BALANCE','BRANCH_ID','LOAN_RELEASE_DATE','LOAN_AMOUNT','LOAN_INSTALLMENT_AMOUNT','LOAN_MATURITY_DATE','COMMENTS']
    datagenerate(records, headers)
    print('CSV generation complete for ACCOUNT CSV!')
