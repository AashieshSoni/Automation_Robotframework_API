import csv
from datetime import datetime, timedelta
import random
import pandas as pd

# Load the CSV file
df = pd.read_csv('ACCOUNTRELATIONSHIP_.csv')

# Get unique ACCOUNT_NUMBER values
unique_account_numbers = df['ACCOUNT'].dropna().unique()

# Convert to a list (optional)
unique_account_numbers_list = unique_account_numbers.tolist()

# Print or use the list
print(f"Found {len(unique_account_numbers_list)} unique ACCOUNT_NUMBERs.")
#print(unique_account_numbers_list)

# Define the columns
columns = [
    'ACCOUNT_NUMBER', 'TYPE', 'PRODUCT_NAME', 'STATUS', 'OPEN_DATE',
    'CLOSE_DATE', 'REOPEN_DATE', 'INITIAL_BALANCE', 'CURRENT_BALANCE',
    'BRANCH_ID', 'LOAN_RELEASE_DATE', 'LOAN_AMOUNT', 'LOAN_INSTALLMENT_AMOUNT',
    'LOAN_MATURITY_DATE', 'COMMENTS'
]

# Helper to generate random dates
def random_date(start, end):
    return start + timedelta(days=random.randint(0, (end - start).days))

# Generate dummy data
# Use the real account numbers
def generate_account_data(account_numbers):
    data = []
    for acc_num in account_numbers:
        open_date = random_date(datetime(2020, 1, 1), datetime(2024, 12, 31))
        #close_date = random_date(open_date, datetime(2025, 1, 1)) if random.random() < 0.1 else ''
        #reopen_date = random_date(datetime(2024, 12, 1), datetime(2025, 3, 31)) if random.random() < 0.1 else ''


        loan_release_date = random_date(datetime(2022, 1, 1), datetime(2025, 1, 1))
        loan_maturity_date = loan_release_date + timedelta(days=random.randint(180, 1825))

        initial_balance = round(random.uniform(100, 50000), 2)
        current_balance = round(initial_balance * random.uniform(0.5, 1.5), 2)
        loan_amount = round(random.uniform(5000, 500000), 2)
        installment = round(loan_amount / random.randint(6, 36), 2)

        row = [
            acc_num,
            random.choice(['LOAN','BOND','CERTIFICATE_DEPOSIT','CHECKING','CREDIT_CARD','EDUCATION_SAVINGS','IRA','OTHER','ROTH_IRA','SAVINGS','LINE_OF_CREDIT','TRUST','FOREIGN_CURRENCY','MONEY_MARKET','BROKERAGE']),
            random.choice(['PERSONAL','BUSINESS','TRUST','CASINO']),
            random.choice(['ACTIVE','CLOSED','FROZEN','INACTIVE','DORMANT']),
            open_date.strftime('%Y-%m-%d'),
            '',
            '',
            #close_date.strftime('%Y-%m-%d') if close_date else '',
            #reopen_date.strftime('%Y-%m-%d') if reopen_date else '',
            initial_balance, current_balance,
            f"BR{random.randint(100, 999)}",
            loan_release_date.strftime('%Y-%m-%d'),
            loan_amount, installment,
            loan_maturity_date.strftime('%Y-%m-%d'),
            random.choice(['', 'No issues', 'Reopened due to customer request'])
        ]
        data.append(row)
    return data

# Write to CSV
def write_account_file(filename, account_numbers):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(columns)
        writer.writerows(generate_account_data(account_numbers))
    print(f"{filename} with {len(account_numbers)} records created.")

# Use real account numbers
write_account_file('ACCOUNT_.csv', unique_account_numbers_list)
