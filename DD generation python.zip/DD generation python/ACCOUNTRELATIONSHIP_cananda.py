import pandas as pd
import random
from faker import Faker

# Initialize Faker
fake = Faker()

# Load the input files
individual_df = pd.read_csv('INDIVIDUAL_.csv')
business_df = pd.read_csv('BUSINESS_.csv')

# Extract unique IDs
individual_ids = individual_df['INDIVIDUAL_ID'].dropna().unique()
business_ids = business_df['BUSINESS_ID'].dropna().unique()

# Define relationship types and weights
relationship_types = [
    "HOLDER", "BORROWER", "TRUSTOR", "CONSERVATOR", "MINOR", "CUSTODIAN",
    "AUTHORIZED_USER", "SIGNERS", "POA", "TRUSTEE", "CONSERVATEE",
    "NON_BANK_MEMBER", "BENEFICIARY", "GUARANTOR", "UNKNOWN", "ORIGINATOR",
    "GRANTOR", "SPOUSE", "INVESTOR", "CONTROLLING_PARTY", "PARENT"
]
typeweights = [5, 1,1, 1, 1, 1, 1, 1, 0.5, 0.25, 0.25, 0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,1]

# Function to create relationship entries
def create_relationship_df(customer_ids, customer_type):
    return pd.DataFrame({
        'ACCOUNT': [f"AC{fake.random_number(digits=6)}" for _ in customer_ids],
        'CUSTOMER_TYPE': customer_type,
        'CUSTOMER_ID': customer_ids,
        'TYPE': random.choices(relationship_types, weights=typeweights, k=len(customer_ids))
    })

# Create relationship DataFrames
individual_relationships = create_relationship_df(individual_ids, 'INDIVIDUAL')
business_relationships = create_relationship_df(business_ids, 'BUSINESS')

# Combine both
relationship_df = pd.concat([individual_relationships, business_relationships], ignore_index=True)

# Save to CSV
relationship_df.to_csv('ACCOUNTRELATIONSHIP_.csv',sep=',', index=False)

