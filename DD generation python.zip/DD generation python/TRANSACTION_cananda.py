import csv
import datetime
from faker import Faker
import random
import pandas as pd

Faker.seed(0)
random.seed(0)
fake = Faker("en_CA") 
fixed_digits = 6

channels=["IN_PERSON","AUTOMATED_BANKING_MACHINE","ARMOURED_CAR","COURIER","MAIL_DEPOSIT","TELEPHONE","NIGHT_DEPOSIT","QUICK_DROP",
"SELF_REDEMPTION_KIOSK","VIRTUAL_CURRENCY_ATM","ONLINE"]
tran_type=["BANK_DRAFT","CASH","CASINO_PRODUCT","CHEQUE","DOMESTIC_FUNDS_TRANSFER","EMAIL_MONEY_TRANSFER","INTERNATIONAL_FUNDS_TRANSFER",
"INVESTMENT_PRODUCT","JEWELLERY","MOBILE_MONEY_TRANSFER","MONEY_ORDER","PRECIOUS_METALS","PRECIOUS_STONES","VIRTUAL_CURRENCY","FUNDS_WITHDRAWAL"]

# Load the input files
account_df = pd.read_csv('ACCOUNT_.csv')

# Extract unique IDs
account_num = account_df['ACCOUNT_NUMBER'].dropna().unique()
print(account_num)

def generate_trn_list(count, start_number=100001, prefix="TR"):
  if count <= 0:
    return [] # Return empty list for non-positive count

  #trn_list = []
  #for i in range(count):
  current_number = start_number + count
  trn_id = f"{prefix}{current_number}"
  #trn_list.append(trn_id)
  return trn_id
 

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1
    
    
def datagenerate(records, headers):
    with open('TRANSACTION_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            writer.writerow({
                'TRANSACTION_ID': generate_trn_list(i, 900001),
                'TYPE': listToString(random.choices(tran_type, weights=[1] * len(tran_type))),
                'BUSINESS_DAY': fake.date_between_dates(
                    date_start=datetime.date(2024, 1, 1), date_end=datetime.date(2025, 3, 31)
                ).strftime('%Y-%m-%d'),
                'DATE': fake.date_between_dates(
                    date_start=datetime.date(2020, 1, 1), date_end=datetime.date(2024, 12, 31)
                ).strftime('%Y-%m-%d'),
                'TIME': fake.time(),
                'AMOUNT': round(random.uniform(4999, 500000), 2),
                'OPERATION': random.choice(['CREDIT', 'DEBIT']),
                'BALANCE': fake.random_number(digits=4),
                'SUBJECT_ACCOUNT_NUMBER': account_num[i % len(account_num)],  # Ensure it wraps if more records than IDs
                'COUNTERPARTY_ACCOUNT_NUMBER': random.choices(
                    [account_num[i % len(account_num)], fake.random_number(digits=6), ""],
                    weights=[1, 0.9, 0.1], k=1
                )[0],
                'COUNTERPARTY_INSTITUTION': fake.name(),
                'COUNTERPARTY_TYPE': '',
                'COUNTERPARTY_ID': fake.random_number(digits=3),
                'CONDUCTOR_NAME': fake.name(),
                'CONDUCTOR_ID': fake.random_number(digits=2),
                'COUNTERPARTY_COUNTRY': 'CA',
                'BRANCH_ID': fake.random_number(digits=4),
                'CHANNEL': listToString(random.choices(channels, weights=[1] * len(channels))),
                'CURRENCY': 'CAD',
                'COUNTERPARTY_NAME': fake.name(),
                'COUNTERPARTY_ROUTING_NUMBER': fake.random_number(digits=5),
                'SUBJECT_COUNTRY': 'CA',
                'MCC_CODE': 'CA',
                'MERCHANT_STATE_CODE': '',
                'TRANSACTION_SERIAL_NUMBER': ' ',
                'PURPOSE': random.choices(
                    ['ONLINE_PAYMENT', 'BANK_TRANSFER', 'SALARY_PAYMENT', 'ACH'], weights=[1, 1, 1, 0.5]
                )[0],
                'COMMENTS': f'Transaction on {account_num[i % len(account_num)]}',
            })

if __name__ == '__main__':
    records = 200
    headers = [ "TRANSACTION_ID", "TYPE", "BUSINESS_DAY", "DATE", "TIME", "AMOUNT", "OPERATION", "BALANCE",
        "SUBJECT_ACCOUNT_NUMBER", "COUNTERPARTY_ACCOUNT_NUMBER", "COUNTERPARTY_INSTITUTION", "COUNTERPARTY_TYPE",
        "COUNTERPARTY_ID", "CONDUCTOR_NAME", "CONDUCTOR_ID", "COUNTERPARTY_COUNTRY", "BRANCH_ID", "CHANNEL",
        "CURRENCY", "COUNTERPARTY_NAME", "COUNTERPARTY_ROUTING_NUMBER", "SUBJECT_COUNTRY", "MCC_CODE",
        "MERCHANT_STATE_CODE", "TRANSACTION_SERIAL_NUMBER", "PURPOSE", "COMMENTS"]
    datagenerate(records, headers)
    print('CSV generation complete!')
