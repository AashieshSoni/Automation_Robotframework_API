import csv
from datetime import datetime, timedelta
from faker import Faker
import random
import pycountry
from mimesis import Person
from mimesis import Address

#from mimesis.enums import Gender

Faker.seed(0)
random.seed(0)
fake = Faker("en_CA") 
person = Person()
addess = Address()



fixed_digits = 6
concatid = 'ID'
input_countries = ['American Samoa', 'Canada', 'France','United States','India']

countries = {}
  
def muliti_value(clist, mcount):
    if len(clist) < mcount:
        raise ValueError("Need at least muliti to pick from.")
    selected = random.sample(clist, mcount)
    return ';'.join(selected)

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1
    
def genderreturned():
    gender = random.choices(['MALE', 'FEMALE'], weights=[0.5, 0.5])  
    return gender    

# Function to generate a name with a chance of being blank
def generate_name_with_blank():
    # Using random.choices to either pick a first name or a blank (empty string)
    name = random.choices([fake.first_name(), ""], weights=[3, 1], k=1)[0]  # Access the first element of the list
    return name
    
# Function to generate a name with a chance of being blank
def generate_lastname_with_blank():
    # Using random.choices to either pick a first name or a blank (empty string)
    name = random.choices([fake.last_name(), ""], weights=[3, 1], k=1)[0]  # Access the first element of the list
    return name
    
    # Function to generate a name with a chance of being blank
def generate_middlename_with_blank():
    # Using random.choices to either pick a first name or a blank (empty string)
    name = random.choices([fake.first_name_male(), ""], weights=[1.8, .2], k=1)[0]  # Access the first element of the list
    return name

def generate_random_datetime(start_date_str, end_date_str, date_format):
    # Convert the strings to datetime objects using strptime
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d %H:%M:%S')
    end_date = datetime.strptime(end_date_str, '%Y-%m-%d %H:%M:%S')

    # Calculate the difference between the two dates
    delta = end_date - start_date

    # Generate a random number of seconds between 0 and the total number of seconds in the delta
    random_seconds = random.randint(0, int(delta.total_seconds()))

    # Add the random seconds to the start date to get a random datetime
    random_datetime = start_date + timedelta(seconds=random_seconds)

    # Return the random datetime in the desired format
    return random_datetime.strftime(date_format)

def datagenerate(records, headers):
    fake = Faker()
    for country in pycountry.countries:
        countries[country.name] = country.alpha_2

    codes = [countries.get(country, 'Unknown code') for country in input_countries]
    channelofaccount=['BRANCH','ONLINE','INDIRECT LENDING','ACQUIRED ACCOUNTS','OTHER']
    service_type=['MONEY TRANSFER','ONLINE BANKING','CHECKING','SECURITY DEALING','DIRECT DEPOSIT ACCOUNT','DEBIT CARD','OTHER']
    client_segment=['CORE BANK','PRIVATE BANK','WEALTH MANAGEMENT','CORPORATE','COMMERCIAL','SMALL BUSINESS','TOP CORE','OTHER']
    collateraltype=['STOCK','BONDS','UNIMPROVED LAND','LAND ACQUISITION AND DEVELOPMENT','COMMERCIAL VEHICLE','AUTOMOBILE NEW','AUTOMOBILE USED','MIXED USE']
    with open('INDIVIDUAL_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            genderOutput = genderreturned()
            date_format = '%Y-%m-%d'
            writer.writerow({
                    'INDIVIDUAL_ID': fake.random_number(digits=8),
                    'IS_CUSTOMER': listToString(random.choices([True, False], weights=[8, 2])),
                    'CLOSE_DATE':'',
                    'CUSTOMER_SINCE': fake.date_time().strftime('%Y-%m-%d %H:%M:%S'),
                    # generate_random_datetime('2024-12-31 00:00:00', '2025-04-30 59:59:59',date_format),
                    'CLOSE_DATE' : str(""),
                    'FIRST_NAME' : generate_name_with_blank(),
                    'MIDDLE_NAME' : generate_middlename_with_blank(), 
                    'LAST_NAME' : generate_lastname_with_blank(),
                    'NAME_SUFFIX' : fake.name(),
                    'ALTERNATE_NAMES' : fake.name(),
                    'GENDER' : listToString(random.choices(['MALE','FEMALE','UNKNOWN'], weights=[4,5,1])),
                    'EMPLOYER' : fake.name(),
                    'INTERNAL_EMPLOYEE' : listToString(random.choices([True, False], weights=[2, 8])),
                    'OCCUPATION' : fake.name(),
                    'MARITAL_STATUS' : listToString(random.choices(['NEVER_MARRIED','MARRIED','SEPARATED','DIVORCED','WIDOWED',"OTHER"], weights=[2, 2, 1, 2, 2,1])),
                    'GROSS_ANNUAL_INCOME' : fake.random_number(digits=6),
                    'NATIONALITY' : listToString(random.choices(codes)),
                    'BIRTH_DATE' :'1990-12-31',
                    #fake.date_time_between(start_date='1990-12-31', end_date='2004-04-30').strftime('%Y-%m-%d'),
                    'TIN_TYPE' : listToString(random.choices(['BN','SIN','ITN'], weights=[1,1,.25])),
                    'TIN' : fake.random_number(digits=10),
                    'EXEMPT_CDD' : listToString(random.choices([True, False], weights=[5, 5])),
                    'EXEMPT_SANCTIONS' : listToString(random.choices([True, False], weights=[5, 5])),
                    'RESIDENCY' : 'CA', #listToString(random.choices(codes)),
                    'TRANSACTIONAL_COUNTRIES' : listToString(codes),
                    'PEP' : listToString(random.choices([True, False], weights=[5, 5])),
                    'SUBPOENA' : listToString(random.choices([True, False], weights=[5, 5])),
                    '314B' : listToString(random.choices([True, False], weights=[5, 5])),
                    'NEGATIVE_NEWS' : listToString(random.choices([True, False], weights=[5, 5])),
                    'OFAC' : listToString(random.choices([True, False], weights=[5, 5])),
                    'CHANNEL_OF_ACCOUNT_OPENING' : muliti_value(channelofaccount,random.randint(1, 4)),
                    'SERVICE_TYPE' : listToString(random.choices(['MONEY TRANSFER','ONLINE BANKING','CHECKING','SECURITY DEALING','DIRECT DEPOSIT ACCOUNT','DEBIT CARD','OTHER'], weights=[2,2,2,1,1,1,1])),
                    'CLIENT_SEGMENT' : listToString(random.choices(['CORE BANK','PRIVATE BANK','WEALTH MANAGEMENT','CORPORATE','COMMERCIAL','SMALL BUSINESS','TOP CORE','OTHER'], weights=[2,2,1,1,1,1,1,1])),
                    'COLLATERAL_TYPE' : listToString(random.choices(['STOCK','BONDS','UNIMPROVED LAND','LAND ACQUISITION AND DEVELOPMENT','COMMERCIAL VEHICLE','AUTOMOBILE NEW','AUTOMOBILE USED','MIXED USE'], weights=[2,2,1,1,1,1,1,1])),
                    'SIC_CODE' : fake.random_number(digits=4),
                    'SOC_CODE' : str('11-1234'),
                    'CITIZENSHIP' : 'CA', #listToString(random.choices(codes)),
                    'TEAM_CODE': listToString(random.choices(['YOLO','SQUAD-2','72-AR','OS007'], weights=[2.5, 2.5, 2.5, 2.5])),
                    'COMMENTS': 'Individual',
                })


if __name__ == '__main__':
    records = 2000
    headers = ['INDIVIDUAL_ID','IS_CUSTOMER','CUSTOMER_SINCE','CLOSE_DATE','FIRST_NAME','MIDDLE_NAME',
'LAST_NAME','NAME_SUFFIX','ALTERNATE_NAMES','GENDER','EMPLOYER','INTERNAL_EMPLOYEE','OCCUPATION','MARITAL_STATUS',
'GROSS_ANNUAL_INCOME','NATIONALITY','BIRTH_DATE','TIN_TYPE','TIN','EXEMPT_CDD','EXEMPT_SANCTIONS','RESIDENCY'
,'TRANSACTIONAL_COUNTRIES','PEP','SUBPOENA','314B','NEGATIVE_NEWS','OFAC','CHANNEL_OF_ACCOUNT_OPENING',
'SERVICE_TYPE','CLIENT_SEGMENT','COLLATERAL_TYPE','SIC_CODE','SOC_CODE','CITIZENSHIP','TEAM_CODE','COMMENTS']
    datagenerate(records, headers)
    print('CSV generation complete!')
