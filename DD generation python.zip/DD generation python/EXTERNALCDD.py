import csv
import datetime
from faker import Faker
import random
import pandas as pd
from datetime import date
from datetime import datetime

Faker.seed(0)
random.seed(0)
fake = Faker("en_US") 
fixed_digits = 6
concatid = 'ID'
df=pd.read_csv("ACCOUNTRELATIONSHIP_exp.csv")

def external_risk_factors():
    external_risk_factor = ['Citizenship Risk', 'Country Risk', 'Geographic Risk', 'PEP indicator Risk', 'NAICS Code Risk', 'Transactional Risk', 'Relationship Length Risk','SAR Filing Risk','Product Risk','CTR Exemption indicator','High-Risk Entities Risk indicator']
    no_of_risk_factors = int(listToString(random.choices([1, 2, 3], weights=[0.33, 0.33,0.33])))
    external_risk_fact = random.choices(external_risk_factor, k=no_of_risk_factors)
    return external_risk_fact

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1
    
def replace_char_at_index(org_str, index, replacement):
    new_str = org_str
    if index < len(org_str):
        new_str = org_str[0:index] + replacement + org_str[index + 1:]
    return new_str    
    
def listToStringRiskFactors(s):
    str1 = ""
    for ele in s:
        str1 = str1 + str(ele) + ','
        str2 = str1[:-1]
    return str2    

def datagenerate(records, headers):
    fake = Faker()
    dfCust = df['CUSTOMER_ID']
    custIDList = dfCust.values.tolist()
    custIDCount = len(custIDList)
    start_date = date.today().replace(day=1, month=1).toordinal()
    end_date = date.today().toordinal()
    random_day = date.fromordinal(random.randint(start_date, end_date))
    current_datetime = datetime.now()
    current_date_time = current_datetime.strftime('%Y-%m-%d %H:%M:%S')
    external_risk_updated_on = "=\"" + current_date_time + "\""
    ext_next_review_date = replace_char_at_index(external_risk_updated_on, 5, str(int(external_risk_updated_on[5])+1))
    external_next_review_date = "=\"" + ext_next_review_date + "\""
    with open('EXTERNALCDD_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            if(i<custIDCount):
                writer.writerow({
                    'SUBJECT_ID': custIDList[i],
                    'ALLOW_XCEED_TO_OVERRIDE_RISK_LEVEL': listToString(random.choices([True, False], weights=[0.5, 0.5])),
                    'EXTERNAL_RISK_LEVEL': listToString(random.choices(['LOW', 'MEDIUM','HIGH'], weights=[3.33,3.33,3.33])),
                    'ALLOW_XCEED_TO_OVERRIDE_RISK_SCORE': listToString(random.choices([True, False], weights=[0.5, 0.5])),
                    'EXTERNAL_RISK_SCORE': fake.random_number(digits=3),
                    'EXTERNAL_RISK_UPDATED_ON': external_risk_updated_on,
                    'EXTERNAL_NEXT_REVIEW_DATE': ext_next_review_date,
                    'EXTERNAL_REVIEW_CYCLE': str(fake.random_number(digits=1))+'-'+listToString(random.choices(['M','Y','W','D'], weights=[0.25, 0.25, 0.25, 0.25])),
                    'EXTERNAL_RISK_FACTORS': listToStringRiskFactors(external_risk_factors())
                })


if __name__ == '__main__':
    records = 25
    headers = ['SUBJECT_ID', 'ALLOW_XCEED_TO_OVERRIDE_RISK_LEVEL', 'EXTERNAL_RISK_LEVEL', 'ALLOW_XCEED_TO_OVERRIDE_RISK_SCORE', 'EXTERNAL_RISK_SCORE', 'EXTERNAL_RISK_UPDATED_ON', 'EXTERNAL_NEXT_REVIEW_DATE', 'EXTERNAL_REVIEW_CYCLE', 'EXTERNAL_RISK_FACTORS']
    datagenerate(records, headers)
    print('CSV generation complete!')
