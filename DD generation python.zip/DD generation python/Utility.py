import random
from datetime import datetime, timedelta

class Utility:
    """
    A class to perform weighted selection of items, supporting single and multiple selections
    with or without replacement.
    """

    @staticmethod
    def select_single_weighted(items, weights):
        if len(items) != len(weights):
            raise ValueError("Items and weights must have the same length.")
        if not items:
            raise ValueError("Input lists cannot be empty.")
        if all(w <= 0 for w in weights):
            raise ValueError("At least one weight must be positive.")

        selected_list = random.choices(items, weights=weights, k=1)
        return selected_list[0]

    @staticmethod
    def select_multi_weighted_with_replacement(items, weights, mcount):
        if len(items) != len(weights):
            raise ValueError("Items and weights must have the same length.")
        if not items:
            raise ValueError("Input lists cannot be empty.")
        if mcount <= 0:
            raise ValueError("mcount (number of items to select) must be positive.")
        if all(w <= 0 for w in weights):
            raise ValueError("At least one weight must be positive.")

        selected = random.choices(items, weights=weights, k=mcount)
        return selected

    @staticmethod
    def select_multi_weighted_without_replacement(items, weights, mcount):
        if len(items) != len(weights):
            raise ValueError("Items and weights must have the same length.")
        if not items:
            raise ValueError("Input lists cannot be empty.")
        if mcount <= 0:
            raise ValueError("mcount (number of items to select) must be positive.")
        if mcount > len(items):
            raise ValueError(f"Cannot select {mcount} unique items from a list of {len(items)}.")
        if all(w <= 0 for w in weights):
            raise ValueError("At least one weight must be positive.")

        selected_items = []
        population = list(items)
        pop_weights = list(weights)

        for _ in range(mcount):
            if not population:
                raise RuntimeError("Population became empty unexpectedly.")

            total_weight = sum(pop_weights)
            if total_weight <= 0:
                if all(w == 0 for w in pop_weights):
                    chosen_item = random.choice(population)
                else:
                    raise ValueError("Cannot perform weighted selection with non-positive total weight.")
            else:
                chosen_list = random.choices(population, weights=pop_weights, k=1)
                chosen_item = chosen_list[0]

            selected_items.append(chosen_item)
            idx_to_remove = population.index(chosen_item)
            del population[idx_to_remove]
            del pop_weights[idx_to_remove]

        return selected_items

def generate_random_datetime(start_date_str, end_date_str, date_format):
    # Convert the strings to datetime objects using strptime
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d %H:%M:%S')
    end_date = datetime.strptime(end_date_str, '%Y-%m-%d %H:%M:%S')

    # Calculate the difference between the two dates
    delta = end_date - start_date

    # Generate a random number of seconds between 0 and the total number of seconds in the delta
    random_seconds = random.randint(0, int(delta.total_seconds()))

    # Add the random seconds to the start date to get a random datetime
    random_datetime = start_date + timedelta(seconds=random_seconds)

    # Return the random datetime in the desired format
    return random_datetime.strftime(date_format)

def muliti_value(clist, mcount):
    if len(clist) < mcount:
        raise ValueError("Need at least muliti to pick from.")
    selected = random.sample(clist, mcount)
    return ';'.join(selected)

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1


def emaildomain():
    emaildomains = ['gmail', 'hotmail', 'live', 'verizon', 'yahoo', 'hotmail', 'comcast']
    emails = listToString(random.choices(emaildomains, weights=[2, 2, 1, 1, 2, 2, 1]))
    return emails


def emailextension():
    ext = ['.com', '.net', '.co.uk']
    emailextension = listToString(random.choices(ext, weights=[4, 4, 3]))
    return emailextension


# Example Usage
if __name__ == "__main__":
    my_list = ['apple', 'banana', 'cherry', 'date', 'elderberry']
    my_weights = [10, 1, 30, 5, 2]

    selector = Utility()

    print("--- Single Selection ---")
    for _ in range(5):
        print(f"Selected: {selector.select_single_weighted(my_list, my_weights)}")

    print("\n--- Multi Selection (With Replacement) ---")
    print(f"Selected (k=3, with replacement): {selector.select_multi_weighted_with_replacement(my_list, my_weights, 3)}")

    print("\n--- Multi Selection (Without Replacement) ---")
    print(f"Selected (k=3, without replacement): {selector.select_multi_weighted_without_replacement(my_list, my_weights, 3)}")