import csv
import datetime
from faker import Faker
import random
import pandas as pd
import numpy as np

Faker.seed(0)
random.seed(0)
fake = Faker("en_US") 
fixed_digits = 6
concatid = 'ID'
df=pd.read_csv("ACCOUNTRELATIONSHIP_exp.csv")

def ownerType():
    ownertype = random.choices(['INDIVIDUAL', 'BUSINESS'], weights=[0.5, 0.5])  
    return ownertype

def emaildomain():
    emaildomains = ['gmail','hotmail','live','verizon','yahoo','hotmail','comcast']
    emails = listToString(random.choices(emaildomains, weights=[2,2,1,1,2,2,1]))
    return emails
    
def emailextension():
    ext = ['.com','.net','.co.uk']
    emailextension = listToString(random.choices(ext, weights=[4,4,3]))
    return emailextension

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1
    
def ownerId(type_owner):
    #lst_owner_id = df[df['CUSTOMER_TYPE'] == s].index.to_numpy()
    dfB = df[df['CUSTOMER_TYPE'] == type_owner]
    #dfOwnerID  = pd.Dataframe(
     #   {
     #   "owner": dfB['CUSTOMER_TYPE_ID'],
        
     #   }
    
    #)
    return dfB['CUSTOMER_ID'].values.tolist()

def datagenerate(records, headers):
    fake = Faker()
    #fake1 = Faker('en_GB')   # To generate phone numbers
    with open('EMAIL_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        owner_id_ind = ownerId('INDIVIDUAL')
        owner_id_bus = ownerId('BUSINESS')
        business_count = len(owner_id_bus)
        individual_count  = len(owner_id_ind)
        j=0
        k=0
        for i in range(records):
            owner_type = ownerType()
            if(listToString(owner_type)=='INDIVIDUAL') and j<individual_count:
                OWNER_ID_var = owner_id_ind[j]
                writer.writerow({
                    'EMAIL_ID': fake.random_number(digits=5),
                    'OWNER_TYPE' : listToString(owner_type),
                    'OWNER_ID' : OWNER_ID_var,
                    'EMAIL' : fake.name().replace(".","").strip().replace(" ","").lower() + '@' + emaildomain() + emailextension(),
                    'IS_PRIMARY' : listToString(random.choices([True, False], weights=[0.5, 0.5])),
                     
                })
                j  = j + 1
                
            elif(listToString(owner_type)=='BUSINESS') and k<business_count:
                OWNER_ID_var = owner_id_bus[k]
                writer.writerow({
                    'EMAIL_ID': fake.random_number(digits=5),
                    'OWNER_TYPE' : listToString(owner_type),
                    'OWNER_ID' : OWNER_ID_var,
                    'EMAIL' : fake.name().replace(".","").strip().replace(" ","").lower() + '@' + emaildomain() + emailextension(),
                    'IS_PRIMARY' : listToString(random.choices([True, False], weights=[0.5, 0.5])),
                     
                })
                k = k + 1

if __name__ == '__main__':
    records = 20
    headers = ['EMAIL_ID', 'OWNER_TYPE', 'OWNER_ID', 'EMAIL', 'IS_PRIMARY']
    datagenerate(records, headers)
    print('CSV generation complete!')
