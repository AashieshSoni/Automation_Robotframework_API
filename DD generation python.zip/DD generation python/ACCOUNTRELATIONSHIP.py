import csv
import datetime
from faker import Faker
import random
import pandas as pd

Faker.seed(0)
random.seed(0)
fake = Faker("en_US") 
fixed_digits = 6
concatid = 'ID'
def datagenerate(records, headers):
    fake = Faker()
    fake1 = Faker('en_GB')   # To generate phone numbers
    with open('ACCOUNTRELATIONSHIP_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            writer.writerow({
                    'SUBJECT_ID': fake.random_number(digits=6), 
                })


if __name__ == '__main__':
    records = 10
    headers = ['SUBJECT_ID', 'ALLOW_XCEED_TO_OVERRIDE_RISK_LEVEL', 'EXTERNAL_RISK_LEVEL', 'ALLOW_XCEED_TO_OVERRIDE_RISK_SCORE', 'EXTERNAL_RISK_SCORE', 'EXTERNAL_RISK_UPDATED_ON', 'EXTERNAL_NEXT_REVIEW_DATE', 'EXTERNAL_REVIEW_CYCLE', 'EXTERNAL_RISK_FACTORS']
    datagenerate(records, headers)
    print('CSV generation complete!')
