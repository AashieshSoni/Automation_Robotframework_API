import csv
import datetime
from faker import Faker
import random
import pandas as pd

Faker.seed(0)
random.seed(0)
fake = Faker("en_US") 
fixed_digits = 6
concatid = 'ID'
def datagenerate(records, headers):
    fake = Faker()
    #fake1 = Faker('en_GB')   # To generate phone numbers
    with open('TRANSACTION_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            writer.writerow({
                    'TRANSACTION_ID': fake.random_number(digits=6), 
                    'BUSINESS_DAY': fake.date(), 
                    'DATE': fake.date(), 
                    'TIME': fake.time(), 
                    'AMOUNT': fake.random_number(digits=5), 
                    'BALANCE': fake.random_number(digits=4),
                    'SUBJECT_ACCOUNT_NUMBER': fake.random_number(digits=6), 
                    'COUNTERPARTY_ACCOUNT_NUMBER': fake.random_number(digits=6), 
                    'COUNTERPARTY_INSTITUTION': fake.name(),
                    'COUNTERPARTY_TYPE': '', 
                    'COUNTERPARTY_ID': fake.random_number(digits=3), 
                    'CONDUCTOR_NAME': fake.name(), 
                    'CONDUCTOR_ID': fake.random_number(digits=2), 
                    'COUNTERPARTY_COUNTRY': 'US', 
                    'BRANCH_ID': fake.random_number(digits=4),
                    'CHANNEL': 'MOBILE', 
                    'CURRENCY': 'USD', 
                    'COMMENTS': 'None', 
                    'OPERATION': 'DEBIT', 
                    'COUNTERPARTY_NAME': fake.name(), 
                    'COUNTERPARTY_ROUTING_NUMBER': fake.random_number(digits=5), 
                    'SUBJECT_COUNTRY': fake.name(), 
                    'MCC_CODE': 'US', 
                    'MERCHANT_STATE_CODE': 'NY',
                })


if __name__ == '__main__':
    records = 10
    headers = ['TRANSACTION_ID', 'BUSINESS_DAY', 'DATE', 'TIME', 'AMOUNT', 'BALANCE',
               'SUBJECT_ACCOUNT_NUMBER', 'COUNTERPARTY_ACCOUNT_NUMBER', 'COUNTERPARTY_INSTITUTION',
               'COUNTERPARTY_TYPE', 'COUNTERPARTY_ID', 'CONDUCTOR_NAME', 'CONDUCTOR_ID', 'COUNTERPARTY_COUNTRY', 'BRANCH_ID',
               'CHANNEL', 'CURRENCY', 'COMMENTS', 'OPERATION', 'COUNTERPARTY_NAME', 'COUNTERPARTY_ROUTING_NUMBER', 'SUBJECT_COUNTRY', 
               'MCC_CODE', 'MERCHANT_STATE_CODE']
    datagenerate(records, headers)
    print('CSV generation complete!')
