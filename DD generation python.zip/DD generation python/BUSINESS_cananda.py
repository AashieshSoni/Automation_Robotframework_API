import csv
from datetime import datetime, timedelta
from faker import Faker
import random
import pandas as pd
import pycountry
import string
from mimesis import Person
from mimesis import Address
from mimesis.enums import Gender

Faker.seed(0)
random.seed(0)
fake = Faker("en_CA")
person = Person()
addess = Address()

fixed_digits = 6
concatid = 'ID'
input_countries = ['American Samoa', 'Canada', 'France','United States','India']
channelofaccount=['BRANCH', 'ONLINE', 'INDIRECT LENDING', 'ACQUIRED ACCOUNTS', 'OTHER']
business_type=['ANONYMOUS OWNERSHIP','AUCTIONEER','BEARER SHARE ENTITIES','CROWDFUNDING','EMBASSY AND CONSULATE','CASINO GAMBLING','INTERNET PHARMACY','INVESTOR VISA FUNDS','JEWELERS','MARIJUANA RELATED BUSINESSES','MONEY SERVICES BUSINESSES','NON-PROFIT ORGANIZATION','PAWNBROKERS','PEOPLE ENTITIES ON OFAC LIST','PRIVATELY OWNED ATM','PRIVATE UNSECURED MONEY LENDERSHIGH','POLITICAL FUNDRAISING',
'SHELL BANK ACCOUNTS','THIRD PARTY PAYMENT PROCESSORS','TELEMARKETERS','TRAVEL AGENCY','VIRTUAL CURRENCIES', 'WEAPONS MANUFACTURING','OTHER']

countries = {}

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1

def muliti_value(clist, mcount):
    if len(clist) < mcount:
        raise ValueError("Need at least muliti to pick from.")
    selected = random.sample(clist, mcount)
    return ';'.join(selected)

def datagenerate(records, headers):
    fake = Faker()
    for country in pycountry.countries:
        countries[country.name] = country.alpha_2

    codes = [countries.get(country, 'Unknown code') for country in input_countries]
    with open('BUSINESS_.csv', 'w', newline='') as csvFile:
        writer = csv.DictWriter(csvFile, fieldnames=headers)
        writer.writeheader()
        for i in range(records):
            N=10
            businessid=fake.random_number(digits=6)
            res = ''.join(random.choices(string.ascii_lowercase +
                             string.digits, k=N))
            writer.writerow({
                    'BUSINESS_ID': businessid,
                    'IS_CUSTOMER': listToString(random.choices([True, False], weights=[8, 2])),
                    'CUSTOMER_SINCE': fake.date_time().strftime('%Y-%m-%d %H:%M:%S'),
                    'CLOSE_DATE': str(""),
                    'NAME':fake.name(),
                    'DBA_NAME':fake.name(),
                    'INDUSTRY_CODE_TYPE' :str('NAICS'),
                    'INDUSTRY_CODE' :fake.random_number(digits=4),
                    'FORMATION_DATE':fake.date_time().strftime('%Y-%m-%d %H:%M:%S'),
                    'FORMATION_COUNTRY': listToString(random.choices(codes)),
                    'WEBSITE_URL':str('www.'+res+".com"),
                    'TIN_TYPE': listToString(random.choices(['BM','SIN','ITN'], weights=[4,4,2])),
                    'TIN':fake.name(), 
                    'EXEMPT_CDD': listToString(random.choices([True, False], weights=[5, 5])), 
                    'EXEMPT_SANCTIONS':listToString(random.choices([True, False], weights=[5, 5])),
                    'OPERATION_COUNTRY':fake.name(), 
                    'BUSINESS TYPE':fake.name(),
                    'TRANSACTIONAL_COUNTRIES':listToString(codes),
                    'SUBPOENA':listToString(random.choices([True, False], weights=[5, 5])),
                    '314B':listToString(random.choices([True, False], weights=[5, 5])),
                    'NEGATIVE_NEWS':listToString(random.choices([True, False], weights=[5, 5])),
                    'OFAC':listToString(random.choices([True, False], weights=[5, 5])),
                    'CHANNEL_OF_ACCOUNT_OPENING':muliti_value(channelofaccount,random.randint(1, 4)),
                    'SERVICE_TYPE':listToString(random.choices(['MONEY TRANSFER','ONLINE BANKING','CHECKING','SECURITY DEALING','DIRECT DEPOSIT ACCOUNT','DEBIT CARD','OTHER'], weights=[2,2,2,1,1,1,1])),
                    'CLIENT_SEGMENT': listToString(random.choices(['CORE BANK','PRIVATE BANK','WEALTH MANAGEMENT','CORPORATE','COMMERCIAL','SMALL BUSINESS','TOP CORE','OTHER'], weights=[2,2,1,1,1,1,1,1])),
                    'COLLATERAL_TYPE': listToString(random.choices(['STOCK','BONDS','UNIMPROVED LAND','LAND ACQUISITION AND DEVELOPMENT','COMMERCIAL VEHICLE','AUTOMOBILE NEW','AUTOMOBILE USED','MIXED USE'], weights=[2,2,1,1,1,1,1,1])),
                    'TEAM_CODE':listToString(random.choices(['YOLO','SQUAD-2','72-AR','OS007'], weights=[2.5, 2.5, 2.5, 2.5])),
                    'COMMENTS': str('Business id :'+str(businessid)),

            })


if __name__ == '__main__':
    records = 100
    headers = ['BUSINESS_ID', 'IS_CUSTOMER', 'CUSTOMER_SINCE', 'CLOSE_DATE', 'NAME', 'DBA_NAME',
 'INDUSTRY_CODE_TYPE', 'INDUSTRY_CODE', 'FORMATION_DATE', 'FORMATION_COUNTRY', 'WEBSITE_URL', 
 'TIN_TYPE', 'TIN', 'EXEMPT_CDD', 'EXEMPT_SANCTIONS', 'OPERATION_COUNTRY', 'BUSINESS TYPE',
 'TRANSACTIONAL_COUNTRIES', 'SUBPOENA', '314B', 'NEGATIVE_NEWS', 'OFAC', 'CHANNEL_OF_ACCOUNT_OPENING', 
 'SERVICE_TYPE', 'CLIENT_SEGMENT', 'COLLATERAL_TYPE', 'TEAM_CODE', 'COMMENTS']
    datagenerate(records, headers)
    print('CSV generation complete!')
