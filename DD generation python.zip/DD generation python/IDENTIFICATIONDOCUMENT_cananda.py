import pandas as pd
import random
import csv
from faker import Faker

# Initialize Faker instance and read the input CSV file
Faker.seed(0)
random.seed(0)
fake = Faker("en_CA") 

# Load data from ACCOUNTRELATIONSHIP_.csv
df = pd.read_csv('ACCOUNTRELATIONSHIP_.csv')
df.columns = df.columns.str.strip()

 # List of CANANDA state abbreviations
states = ['AB','BC','MB','NB','NL','NT','NS','NU','ON','PE','QC','SK','YT']
doctype = ['BIRTH_CERTIFICATE','PASSPORT',"DRIVER'S_LICENCE",'PROVINCIAL_HEALTH_CARD','CITIZENSHIP_CARD','CERTIFICATE_OF_INDIAN_STATUS'
,'SOCIAL_INSURANCE_NUMBER_(SIN)_CARD','PERMANENT_RESIDENT_CARD','RECORD_OF_LANDING','CREDIT_FILE','GOVERNMENT_ISSUED_IDENTIFICATION','INSURANCE_DOCUMENTS'
,'PROVINCIAL_OR_TERRITORIAL_IDENTITY_CARD','RECORD_OF_EMPLOYMENT','TRAVEL_VISA','UTILITY_STATEMENT','ARTICLES_OF_ASSOCIATION','CERTIFICATE_OF_CORPORATE_STATUS'
,'CERTIFICATE_OF_INCORPORATION','CERTIFICATE_OF_INCORPORATION','CERTIFICATE_OF_INCORPORATION','ANNUAL_REPORT','OTHER']

# Define headers for the new CSV
headers = ['DOCUMENT_ID', 'OWNER_TYPE', 'OWNER_ID', 'EXPIRATION_DATE', 'TYPE', 'TYPE_DESCRIPTION', 'NUMBER', 'ISSUING_STATE', 
'ISSUING_COUNTRY', 'COMMENTS']

def listToString(s):
    str1 = ""
    for ele in s:
        str1 += str(ele)
    return str1


# Generate fake data
def generate_id_doc_data(num_records):
    data = []
    for i, (owner_id, owner_type) in enumerate(df[['CUSTOMER_ID', 'CUSTOMER_TYPE']].values.tolist(), start=100001):
        document_id = f'D{i}'  # Generate DOCUMENT_ID like D100001
        expiration_date = fake.date_this_decade()  # Generate random expiration date
        doc_type = listToString(random.choices(doctype, weights=[2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,.5,.5,2]))
        issuing_state = random.choice(states)  # Randomly select a CANANDA state
        issuing_country = 'CA'  # Fixed as per the requirement
        comments = f'{document_id} - {owner_id}-{owner_type}'  # Concatenate for COMMENTS
        
        # Append the data row
        row = [
            document_id, owner_type, owner_id, expiration_date, doc_type, doc_type, fake.random_int(min=1000, max=9999),
            issuing_state, issuing_country, comments
        ]
        data.append(row)
    
    return data

# Write to CSV
def write_id_doc_file(filename, num_records):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(generate_id_doc_data(num_records))
    print(f"{filename} with {num_records} records created.")

# Generate 100 records and save to ID_DOC.csv
write_id_doc_file('IDENTIFICATIONDOCUMENT_.csv', len(df))
