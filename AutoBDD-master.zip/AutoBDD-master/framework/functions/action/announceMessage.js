/**
 * make announcement and console log message
 * @param  {String}   element Element selector
 */
module.exports = (message) => {
    console.log(message);
};
