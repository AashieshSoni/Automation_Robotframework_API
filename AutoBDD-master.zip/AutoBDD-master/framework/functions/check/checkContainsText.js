/**
 * Check if the given elements contains text
 * @param  {String}   elementType   Element type (element or button)
 * @param  {String}   element       Element selector
 * @param  {String}   falseCase     Whether to check if the content contains
 *                                  the given text or not
 * @param  {String}   expectedText  The text to check against
 */

const parseExpectedText = require('../common/parseExpectedText');

module.exports = (elementType, element, falseCase, expectedText) => {
    /**
     * The expected text to validate against
     * @type {String}
     */
    var parsedElement = parseExpectedText(element);

    /**
     * The expected text to validate against
     * @type {String}
     */
    var parsedExpectedText = parseExpectedText(expectedText);

    /**
     * The command to perform on the browser object
     * @type {String}
     */
    let command = 'getText';

    if (
        browser.getText(parsedElement) == '' &&
        browser.getAttribute(parsedElement, 'value') !== null
    ) {
        command = 'getValue';
    }

    /**
     * False case
     * @type {Boolean}
     */
    let boolFalseCase;

    /**
     * The text of the element
     * @type {String}
     */
    const text = browser[command](parsedElement);

    if (typeof expectedText === 'undefined') {
        parsedExpectedText = falseCase;
        boolFalseCase = false;
    } else {
        boolFalseCase = (falseCase === ' not');
    }

    if (boolFalseCase) {
        expect(text).not.toContain(parsedExpectedText);
    } else {
        expect(text).toContain(parsedExpectedText);
    }
};
